package com.example.task_2.viewmodel;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.databinding.ObservableArrayMap;
import android.databinding.ObservableInt;
import android.view.View;

import com.bumptech.glide.Glide;
import com.example.task_2.Model.CustomeAdapter;
import com.example.task_2.Model.DataModel;
import com.example.task_2.Model.DataModelDto;
import com.example.task_2.R;

import java.util.List;

public class MainViewModel extends ViewModel {
    private DataModelDto dataModel;
    private CustomeAdapter adapter;
    public MutableLiveData<DataModel> selected;
    public ObservableInt loading;
    public ObservableInt showEmpty;
    public void init() {
        dataModel = new DataModelDto();
        selected = new MutableLiveData<>();
        adapter = new CustomeAdapter(R.layout.item_movie, this);
        loading = new ObservableInt(View.GONE);
        showEmpty = new ObservableInt(View.GONE);
    }
    public void fetchList() {
        dataModel.fetchList();
    }
    public MutableLiveData<List<DataModel>> getBreeds() {
        return dataModel.getBreeds();
    }
    public CustomeAdapter getAdapter() {
        return adapter;
    }
    public void setInAdapter(List<DataModel> breeds) {
        this.adapter.setMovie(breeds);
        this.adapter.notifyDataSetChanged();
    }
    public MutableLiveData<DataModel> getSelected() {
        return selected;
    }
    public DataModel getMovieAt(Integer index) {
        if (dataModel.getBreeds().getValue() != null &&
                index != null &&
                dataModel.getBreeds().getValue().size() > index) {
            return dataModel.getBreeds().getValue().get(index);
        }
        return null;
    }
    public void fetchImagesAt(Integer index) {

    }



    }
