package com.example.task_2.Model;

import android.arch.lifecycle.MutableLiveData;
import android.databinding.BaseObservable;

import com.example.task_2.Networking.Api;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DataModelDto extends BaseObservable {
    public String apiKey = "31521ab741626851b73c684539c33b5a";


    private String status;
    private List<DataModel> results = null;
    private MutableLiveData<List<DataModel>> breeds = new MutableLiveData<>();

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void addmovie(DataModel bd) {
        results.add(bd);
    }

    public MutableLiveData<List<DataModel>> getBreeds() {
        return breeds;
    }

    public void fetchList() {
        Callback<DataModelDto> callback = new Callback<DataModelDto>() {
            @Override
            public void onResponse(Call<DataModelDto> call, Response<DataModelDto> response) {
                DataModelDto dataModelDto = response.body();
                status = dataModelDto.status;
                breeds.setValue(dataModelDto.results);

            }

            @Override
            public void onFailure(Call<DataModelDto> call, Throwable t) {
            }
        };
        Api.DataInterface dataInterface = Api.getRetrofitInstance().create(Api.DataInterface.class);
        dataInterface.getUsers(apiKey);

    }
}